//2-7. Feladat - printable interface letrehozasa
public interface Printable {
	void print();
}