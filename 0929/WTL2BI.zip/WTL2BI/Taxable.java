//2-1. Feladat - Taxable interface letrehozasa
public interface Taxable {
	double adoAlap();
	
	//2-6. Feladat - default metodus
	default boolean magasAdo() {
		return adoAlap() > 100000;
	}
}

//Valasz: 2-6. Feladat
/*
Nem kell modositani a Vehicle vagy Property osztalyokat, mert ez egy default metodus,
tehat a megvalosito osztalyok automatikusan megoroklik
*/