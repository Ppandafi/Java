//1-1. Feladat - osztaly leterehozasa
public class Engine {
	private int teljesitmenyKw;
	private String uzemanyag;
	
	//1-2. Feladat - konstruktorok
	public Engine(int teljesitmenyKw, String uzemanyag) {
		this.teljesitmenyKw = teljesitmenyKw;
		this.uzemanyag = uzemanyag;
	}
	
	public Engine(int teljesitmenyKw) {
		this(teljesitmenyKw, "benzin");
	}
	
	//1-3. Feladat - getterek es setter
	public int getTeljesitmenyKw() {
		return teljesitmenyKw;
	}
	
	public String getUzemanyag() {
		return uzemanyag;
	}
	
	public void setTeljesitmenyKw(int teljesitmenyKw) {
		if (teljesitmenyKw > 0) {
			this.teljesitmenyKw = teljesitmenyKw;
		} else {
			System.out.println("Hibas ertek: A teljesitmenynek pozitivnak kell lennie");
		}
	}
	
	//1-5. Feladat - parameterek nelkuli konstruktor
	public Engine() {
	}
	
	@Override
	public String toString() {
		return teljesitmenyKw + " kW, " + uzemanyag;
	}
}

//Valasz: 1-3. Feladat
/*
Azert nem kell mindenhez settert irni, mert vannak olyan adatok, amik az objektum letrehozasa
utan nem valtoznak (pl. hasznalt uzemanyag tipusa)
*/
