//2-2. Feladat - Property oszaly letrehozasa
public class Property implements Taxable, Printable {
	private String cim;
	private double alapteruletM2;
	
	public Property(String cim, double alapteruletM2) {
		this.cim = cim;
		this.alapteruletM2 = alapteruletM2;
	}
	
	public String getCim() {
		return cim;
	}
	
	public double getAlapteruletM2() {
		return alapteruletM2;
	}
	
	//2-4. Feladat - Taxable interface megvalositasa
	@Override
	public double adoAlap() {
		return alapteruletM2 * 1000;
	}
	
	//2-7. Feladat - Printable interface megvalositasa
	@Override
	public void print() {
		System.out.println("Ingatlan cime: " + cim + ", alapterulete: " + alapteruletM2 + "m2");
	}
}