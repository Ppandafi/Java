//1-4. Feladat FleetApp osztaly letrehozasa
public class FleetApp {
	/*1-15. Feladat
	public static double osszAdo(Vehicle[] flotta) {
		double ossz = 0;
		for (Vehicle v : flotta) {
			ossz += v.adoAlap();
		}
		 return ossz;
	}
	*/
	
	//2-5. Feladat - osszAdo metodus Taxable[] tombbel
	public static double osszAdo(Taxable[] elemek) {
		double ossz = 0;
		for (Taxable t : elemek) {
			ossz += t.adoAlap();
		}
		return ossz;
	}
	
	//2-8. Feladat - listaz metodus
	public static void listaz(Printable[] elemek) {
		System.out.println("-- Nyomtatható elemek listája --");
		for(Printable p : elemek) {
			p.print();
		}
	}
	
	public static void main(String[] args) {
		//1-5. Feladat - ures motor tesztelese
		Engine uresMotor = new Engine();
		System.out.println("Ures motor teljesitmenye: " + uresMotor.getTeljesitmenyKw() + ", uzemanyaga: " + uresMotor.getUzemanyag());
		
		//1-11. Feladat - autok es teherautok peldanyositasa
		Engine e1 = new Engine(110, "dizel");
		Engine e2 = new Engine(250, "elektromos");
		
		Car auto = new Car("ABC-123", "Toyota", 2020, e1, 5);
		Truck kamion = new Truck("KMN-999", "Volvo", 2018, e1, 15.5);
		ElectricCar villanyauto = new ElectricCar("ZLD-001", "Tesla", 2024, e2, 5, 450);
		
		auto.print();
		kamion.print();
		villanyauto.print();
		
		/*
		Vehicle[] jarmuFlotta = {auto, kamion, villanyauto};
		for (Vehicle v : jarmuFlotta) {
			System.out.println(v.getRendszam() + "adoalapja: " + v.adoAlap());
		}
		*/
		
		//2-3. Feladat - ingatlan peldanyositasa
		Property haz = new Property("1011 Budapest, Fo utca 1.", 120);
		
		//2-5. Feladat - Vegyes tomb
		Taxable[] adoztathatoDolgok = {auto, kamion, villanyauto, haz};
		System.out.println("Kulonallo adoalapok:");
		for(Taxable t : adoztathatoDolgok) {
			System.out.print("- Adoalap: " + t.adoAlap() + "(Magas ado? " + (t.magasAdo() ? "Igen" : "Nem") + ")");
		}
		System.out.println("Teljes adoalap: " + osszAdo(adoztathatoDolgok));
		
		//2-8. Feladat - listaz metodus tesztelese
		Printable[] nyomtathatoDolgok = {auto, haz, kamion};
		listaz(nyomtathatoDolgok);
	}
}

//Valaszok:
//2-5. Feladat:
/*
Mivel a property nem egy vehicle, igy logikailag hibas lenne oket egy kozos ososztalyba kenyszeriteni
*/
//2-8. Feladat:
/*
Igen, mivel a property osztaly implementalja a taxable es printable interface-ket, igy az altala
letrehozott objektum hivatkozasa bekerulhet mindket tombbe
*/