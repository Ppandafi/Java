import java.time.Year;

//1-13. Feladat - absztaktta tetel
//2-2/7. Feladat - taxable es printable implementacio
//1-6. Feladat - Vehicle osztaly letrehozasa
public abstract class Vehicle implements Taxable, Printable {
	private String rendszam;
	private String gyarto;
	private int gyartasEv;
	private Engine motor;
	
	//1-7. Feladat - konstruktorok
	public Vehicle(String rendszam, String gyarto, int gyartasEv, Engine motor) {
		this.rendszam = rendszam;
		this.gyarto = gyarto;
		this.gyartasEv = gyartasEv;
		this.motor = motor;
	}
	
	public Vehicle(String rendszam, Engine motor) {
		this(rendszam, "ismeretlen", 2026, motor);
	}
	
	//1-8. Feladat - getterek, setterek
	public String getRendszam() {
		return rendszam;
	}
	
	public String getGyarto() {
		return gyarto;
	}
	
	public int getGyartasEv() {
		return gyartasEv;
	}
	
	public Engine getMotor() {
		return motor;
	}
	
	public void setGyarto(String gyarto) {
		this.gyarto = gyarto;
	}
	
	public void setGyartasEv(int gyartasEv) {
		this.gyartasEv = gyartasEv;
	}
	
	//1-9. Feladat - print() es kor() metodusok
	public void print() {
		System.out.println(this.toString());
	}
	
	public int kor() {
		int aktualisEv = Year.now().getValue();
		return aktualisEv-gyartasEv;
	}
	
	//1-12. Feladat -  adoAlap() metodus
	//public abstract adoAlap()
	
	//1-14. Feladat - toString() felulirasa
	@Override
	public String toString() {
		return "Jarmu: " + rendszam + " (" + gyarto + ", " + gyartasEv + ") - Motor: " + (motor != null ? motor.toString() : "nincs");
	}
}

//Valaszok:
//1-8. Feladat:
/*
Azert ne lehessen megvalositani a jarmuvek rendszamat, mivel az az egyedi azonositojuk a nyilvantartasban
*/
//1-13. Feladat:
/*
Nem, mivel miutan megkapta az "abstract" kulcsszot, maga az osztaly mar nem peldanyosithato, csak a leszarmazottai
*/
//2-2. Feladat:
/*
Nincs szukseg az absztakt adoAlap() deklaraciora, mert ha egy absztakt osztaly implemental egy
interfacet, akkor nem kotelezo megvalositania annak a metodusait, mert azok automatikusan oroklodnek
*/
//2-7. Feladat:
/*
Azert nem kell a Vehicle osztalyhoz uj metodust irni, mert az 1-9. Feladatban mar keszitettunk egy
"public void print()" metodust
*/
