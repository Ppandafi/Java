//1-10. Feladat Car osztaly
public class Car extends Vehicle {
	private int ulesekSzama;
	
	public Car(String rendszam, String gyarto, int gyartasEv, Engine motor, int ulesekSzama) {
		super(rendszam, gyarto, gyartasEv, motor);
		this.ulesekSzama = ulesekSzama;
	}
	
	//1-12. Feladat - adoAlap() felulirasa
	@Override
	public double adoAlap() {
		if(getMotor() != null) {
			return getMotor().getTeljesitmenyKw() * 500;
		}
		return 0;
	}
	
	//1-14. Feladat - toString() felulirasa
	@Override
	public String toString() {
		return super.toString() + " | Ulesek szama: " + ulesekSzama;
	}
}