//1-16. Feladat - ElectricCar osztaly letrehozasa
public class ElectricCar extends Car {
	private int hatotavKm;
	
	public ElectricCar(String rendszam, String gyarto, int gyartasEv, Engine motor, int ulesekszama, int hatotavKm) {
		super(rendszam, gyarto, gyartasEv, motor, ulesekszama);
		this.hatotavKm = hatotavKm;
	}
}

//Valasz: 1-16. Feladat
/*
A konstruktorok lancolataban mindig legeloszor a legfelso os konstruktora fut le,
majd inicializalodnak a konktet osztalyok
itt: Vehicle konstruktor -> Car konstruktor -> ElectricCar konstruktor

Mivel oroklodik a Car oszalybol, ezert annak az adoAlap() metodusa fog lefutni: motor teljesitmenye * 500
*/