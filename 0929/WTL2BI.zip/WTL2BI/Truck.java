//1-10. Feladat - Truck osztaly letrehozasa
public class Truck extends Vehicle {
	private double teherbirasTonna;
	
	public Truck(String rendszam, String gyarto, int gyartasEv, Engine motor, double teherbirasTonna) {
		super(rendszam, gyarto, gyartasEv, motor);
		this.teherbirasTonna = teherbirasTonna;
	}
	
	//1-12. Feladat - adoAlap() felulirasa
	@Override
	public double adoAlap() {
		return teherbirasTonna * 12000;
	}
	
	//1-14. Feladat - toString() felulirasa
	@Override
	public String toString() {
		return super.toString() + " | Teherbiras: " + teherbirasTonna + " tonna";
	}
}